public enum ItemType
{
    Fish,Bait,FishingRod,smallFish,bigFish,rareFish
}

public enum SlotType
{
    Bag, Box, Shop
}

public enum Habitat
{
    lake, sea, everywhere
}

public enum InventoryLocation
{
    Player, Box, Shop
}